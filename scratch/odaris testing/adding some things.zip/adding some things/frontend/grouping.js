function setThingsToMoveTogether () {
//something something
}
